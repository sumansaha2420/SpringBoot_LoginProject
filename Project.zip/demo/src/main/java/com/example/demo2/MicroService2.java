package com.example.demo2;

public class MicroService2 {

}
